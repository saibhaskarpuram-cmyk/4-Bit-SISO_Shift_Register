module siso_shift_register (clk,
    rst,
    serial_in,
    serial_out,
    VPWR,
    VGND);
 input clk;
 input rst;
 input serial_in;
 output serial_out;
 input VPWR;
 input VGND;

 sky130_fd_sc_hd__nor2b_1 _04_ (.A(rst),
    .B_N(shift_reg[1]),
    .Y(_02_));
 sky130_fd_sc_hd__nor2b_1 _05_ (.A(rst),
    .B_N(shift_reg[2]),
    .Y(_03_));
 sky130_fd_sc_hd__nor2b_1 _06_ (.A(rst),
    .B_N(serial_in),
    .Y(_00_));
 sky130_fd_sc_hd__nor2b_1 _07_ (.A(rst),
    .B_N(shift_reg[0]),
    .Y(_01_));
 sky130_fd_sc_hd__dfxtp_1 _08_ (.D(_00_),
    .Q(shift_reg[0]),
    .CLK(clknet_1_1__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _09_ (.D(_01_),
    .Q(shift_reg[1]),
    .CLK(clknet_1_1__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _10_ (.D(_02_),
    .Q(shift_reg[2]),
    .CLK(clknet_1_0__leaf_clk));
 sky130_fd_sc_hd__dfxtp_1 _11_ (.D(_03_),
    .Q(shift_reg[3]),
    .CLK(clknet_1_0__leaf_clk));
 sky130_fd_sc_hd__decap_4 PHY_0 ();
 sky130_fd_sc_hd__decap_4 PHY_1 ();
 sky130_fd_sc_hd__decap_4 PHY_2 ();
 sky130_fd_sc_hd__decap_4 PHY_3 ();
 sky130_fd_sc_hd__decap_4 PHY_4 ();
 sky130_fd_sc_hd__decap_4 PHY_5 ();
 sky130_fd_sc_hd__decap_4 PHY_6 ();
 sky130_fd_sc_hd__decap_4 PHY_7 ();
 sky130_fd_sc_hd__decap_4 PHY_8 ();
 sky130_fd_sc_hd__decap_4 PHY_9 ();
 sky130_fd_sc_hd__decap_4 PHY_10 ();
 sky130_fd_sc_hd__decap_4 PHY_11 ();
 sky130_fd_sc_hd__decap_4 PHY_12 ();
 sky130_fd_sc_hd__decap_4 PHY_13 ();
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_clk (.A(clk),
    .X(clknet_0_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_1_0__f_clk (.A(clknet_0_clk),
    .X(clknet_1_0__leaf_clk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_1_1__f_clk (.A(clknet_0_clk),
    .X(clknet_1_1__leaf_clk));
endmodule
