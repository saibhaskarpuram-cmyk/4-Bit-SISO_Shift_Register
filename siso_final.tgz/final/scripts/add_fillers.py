import re, glob, os
lib = os.path.expanduser("~") + "/sky130_hd_timing_libs"
src, dst = "pnr/06_droute.def", "pnr/06_droute_fill.def"

def width(cell):
    fs = [f for f in glob.glob(f"{lib}/cells/*/{cell}.lef") if not f.endswith(".magic.lef")]
    m = re.search(r"SIZE\s+([\d.]+)\s+BY", open(fs[0]).read())
    return round(float(m.group(1)) * 1000)

text = open(src).read()
a = re.search(r"^COMPONENTS\s+(\d+)\s*;", text, re.M)
b = text.index("END COMPONENTS")
pat = re.compile(r"-\s+(\S+)\s+(\S+)\s+\+\s+(?:PLACED|FIXED)\s+\(\s*(\d+)\s+(\d+)\s*\)\s+(\S+)\s*;")
comps = [(n, t, int(x), int(y), o) for n, t, x, y, o in pat.findall(text[a.end():b])]

rows = {}
for c in comps:
    rows.setdefault(c[3], []).append(c)

fills, k = [], 0
for y in sorted(rows):
    r = sorted(rows[y], key=lambda c: c[2])
    for cur, nxt in zip(r, r[1:]):
        x = cur[2] + width(cur[1])
        gap = nxt[2] - x
        while gap >= 460:
            for n, w in ((8, 3680), (4, 1840), (2, 920), (1, 460)):
                if gap >= w:
                    break
            fills.append(f"    - FILL_{k} sky130_fd_sc_hd__fill_{n} + PLACED ( {x} {y} ) {r[0][4]} ;")
            print(f"row y={y/1000:.2f}: fill_{n} at x={x/1000:.2f} um")
            k += 1; x += w; gap -= w
        if gap:
            print("WARNING: leftover gap", gap, "at", cur[0])

new = text[:a.start()] + f"COMPONENTS {int(a.group(1)) + len(fills)} ;" + text[a.end():b] + "\n".join(fills) + "\n" + text[b:]
open(dst, "w").write(new)
print("added", len(fills), "filler cells ->", dst)
