include RBA
view = LayoutView.new
view.load_layout($gds, true)
view.load_layer_props($lyp) if $lyp && File.exist?($lyp)
begin
  view.add_missing_layers
rescue
end
view.max_hier
view.zoom_fit
view.save_image($out, 1600, 1600)
puts "saved #{$out}"
