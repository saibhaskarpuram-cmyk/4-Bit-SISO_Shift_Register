include RBA
ly = Layout.new
ly.read($gds)
top = ly.top_cells.find { |c| c.name == ($topc || "siso_shift_register") } || ly.top_cells.first
top.flatten(true)
spec = { "li1"=>[67,20], "mcon"=>[67,44], "met1"=>[68,20], "via"=>[68,44], "met2"=>[69,20],
         "via2"=>[69,44], "met3"=>[70,20], "via3"=>[70,44], "met4"=>[71,20], "via4"=>[71,44], "met5"=>[72,20] }
chain = ["li1","mcon","met1","via","met2","via2","met3","via3","met4","via4","met5"]
if $mode == "cell"
  probes = [["VGND","met1",1.0,0.0], ["VPWR","met1",1.0,2.72]]
else
  probes = [["VPWR","met1",20.0,8.16], ["VGND","met1",20.0,10.88], ["_03_","li1",26.45,18.53],
            ["clknet_0","li1",22.77,14.79], ["_00_","li1",26.45,13.09]]
end
[3,5,7,9,11].each do |n|
  used = chain[0, n]
  l2n = LayoutToNetlist.new(RecursiveShapeIterator.new(ly, top, []))
  reg = {}
  used.each { |nm| l, d = spec[nm]; reg[nm] = l2n.make_layer(ly.layer(l, d), nm) }
  used.each { |nm| l2n.connect(reg[nm]) }
  used.each_cons(2) { |a, b| l2n.connect(reg[a], reg[b]) }
  l2n.extract_netlist
  ids = {}
  probes.each { |nm, lay, x, y| nn = l2n.probe_net(reg[lay], DPoint.new(x, y)); ids[nm] = nn ? nn.cluster_id : nil }
  names = ids.keys
  pairs = []
  names.each_with_index { |a, i| names[(i+1)..-1].each { |b| pairs << "#{a}=#{b}" if ids[a] && ids[a] == ids[b] } }
  miss = ids.select { |k, v| v.nil? }.keys
  puts "up to #{used.last.ljust(5)}: " + (pairs.empty? ? "all separate" : pairs.join(" ")) + (miss.empty? ? "" : "   (no shape at: #{miss.join(',')})")
end
