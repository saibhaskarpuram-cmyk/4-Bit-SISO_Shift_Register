import re, os
home = os.path.expanduser("~")
V = home + "/.volare/volare/sky130/versions/c6d73a35f524070e85faff4a6a9eef49553ebc2b/sky130A"
SP = V + "/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice"
VLOG, DEF, OUT = "netlist/siso_shift_register_postroute.v", "pnr/06_droute_fill.def", "lvs/siso_schematic.spice"

pins, cur = {}, None
for line in open(SP):
    if line.lower().startswith(".subckt"):
        t = line.split(); cur = t[1]; pins[cur] = [p for p in t[2:] if "=" not in p]
    elif line.startswith("+") and cur:
        pins[cur] += [p for p in line[1:].split() if "=" not in p]
    else:
        cur = None

txt = re.sub(r"//.*", "", open(VLOG).read())
m = re.search(r"module\s+(\w+)\s*\((.*?)\)\s*;", txt, re.S)
top = m.group(1)
ports = [p.strip() for p in m.group(2).split(",") if p.strip() and p.strip() not in ("VPWR", "VGND")]
power = {"VPWR": "VPWR", "VPB": "VPWR", "VGND": "VGND", "VNB": "VGND"}
sp = lambda n: n.replace("\\", "").replace("[", "_").replace("]", "_").replace(" ", "")

lines = [f".include {SP}", f".subckt {top} " + " ".join(sp(p) for p in ports) + " VPWR VGND"]
seen, skipped = set(), set()

def add(cell, name, conns):
    if cell not in pins:
        skipped.add(cell); return
    args = []
    for p in pins[cell]:
        if p in power: args.append(power[p])
        elif p in conns: args.append(sp(conns[p]))
        else: args.append(f"NC_{sp(name)}_{p}")
    lines.append(f"X{sp(name)} " + " ".join(args) + f" {cell}")

for cell, name, body in re.findall(r"(sky130_fd_sc_hd__\w+)\s+(\S+)\s*\((.*?)\)\s*;", txt, re.S):
    seen.add(name)
    add(cell, name, dict(re.findall(r"\.(\w+)\s*\(\s*([^)]*?)\s*\)", body)))
for name, cell in re.findall(r"-\s+(\S+)\s+(sky130_fd_sc_hd__\w+)\s+\+\s+(?:PLACED|FIXED)", open(DEF).read()):
    if name not in seen:
        add(cell, name, {})
lines.append(f".ends {top}")
open(OUT, "w").write("\n".join(lines) + "\n")
print("top:", top, "ports:", ports)
print("instances written:", len(lines) - 3, " skipped (no spice model):", sorted(skipped))
