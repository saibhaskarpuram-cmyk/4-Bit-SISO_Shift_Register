import re
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

text = open("sim_results/rtl.vcd").read()
m = re.search(r"\$timescale\s+(\d+)\s*(\w+)", text)
unit = {"s": 1e9, "ms": 1e6, "us": 1e3, "ns": 1.0, "ps": 1e-3, "fs": 1e-6}[m.group(2)]
scale = int(m.group(1)) * unit            # file time unit -> ns

want = ["clk", "rst", "serial_in", "serial_out"]
ids, depth, defs_done, t = {}, 0, False, 0.0
changes = {n: [] for n in want}
for line in text.splitlines():
    s = line.strip()
    if not s:
        continue
    if not defs_done:
        if s.startswith("$scope"):
            depth += 1
        elif s.startswith("$upscope"):
            depth -= 1
        elif s.startswith("$var") and depth == 1:
            p = s.split()
            if p[4] in want:
                ids[p[3]] = p[4]
        elif s.startswith("$enddefinitions"):
            defs_done = True
        continue
    if s.startswith("#"):
        t = int(s[1:]) * scale
    elif s[0] in "01xXzZ" and s[1:] in ids:
        changes[ids[s[1:]]].append((t, s[0]))

end = t
fig, axes = plt.subplots(len(want), 1, sharex=True, figsize=(10, 4.2))
for ax, name in zip(axes, want):
    xs, ys, last = [0.0], [0], 0
    for tm, v in changes[name]:
        val = 1 if v == "1" else 0
        xs += [tm, tm]; ys += [last, val]; last = val
    xs.append(end); ys.append(last)
    ax.step(xs, ys, where="post", linewidth=1.6)
    ax.set_ylim(-0.3, 1.3); ax.set_yticks([0, 1]); ax.set_ylabel(name, rotation=0, ha="right", va="center")
    ax.grid(True, alpha=0.3)
axes[-1].set_xlabel("time (ns)")
axes[0].set_title("RTL simulation: 4-stage serial delay line")
plt.tight_layout()
plt.savefig("sim_results/rtl_waveform.png", dpi=150)
print("signals found:", {n: len(v) for n, v in changes.items()})
