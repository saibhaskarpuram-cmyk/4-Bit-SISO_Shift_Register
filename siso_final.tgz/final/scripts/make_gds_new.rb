include RBA

lib = ENV["HOME"] + "/sky130_hd_timing_libs"
pdk = ENV["HOME"] + "/.volare/volare/sky130/versions/c6d73a35f524070e85faff4a6a9eef49553ebc2b/sky130A/libs.ref/sky130_fd_sc_hd/gds/sky130_fd_sc_hd.gds"
lefs = [lib + "/tech/sky130_fd_sc_hd__nom.tlef"]
lefs += Dir.glob(lib + "/cells/*/sky130_fd_sc_hd__*.lef").reject { |f| f.end_with?(".magic.lef") }

cfg = LEFDEFReaderConfiguration.new
cfg.lef_files = lefs
cfg.read_lef_with_def = false
opt = LoadLayoutOptions.new
opt.lefdef_config = cfg

ly = Layout.new
ly.read("pnr/06_droute_fill.def", opt)

map = {
  "OUTLINE" => [235, 4],
  "li1" => [67, 20], "li1.PIN" => [67, 16], "li1.LABEL" => [67, 5],
  "mcon" => [67, 44],
  "met1" => [68, 20], "met1.PIN" => [68, 16], "met1.LABEL" => [68, 5],
  "via" => [68, 44],
  "met2" => [69, 20], "met2.PIN" => [69, 16], "met2.LABEL" => [69, 5],
  "via2" => [69, 44],
  "met3" => [70, 20], "met3.PIN" => [70, 16], "met3.LABEL" => [70, 5],
  "via3" => [70, 44],
  "met4" => [71, 20], "met4.PIN" => [71, 16], "met4.LABEL" => [71, 5],
  "via4" => [71, 44],
  "met5" => [72, 20], "met5.PIN" => [72, 16], "met5.LABEL" => [72, 5]
}
ly.layer_indexes.each do |i|
  nm = ly.get_info(i).name
  ly.set_info(i, LayerInfo.new(map[nm][0], map[nm][1])) if map.key?(nm)
end

gopt = LoadLayoutOptions.new
gopt.cell_conflict_resolution = LoadLayoutOptions::CellConflictResolution::OverwriteCell
ly.read(pdk, gopt)

# drop every library cell that the design does not use
ly.top_cells.map { |c| c.cell_index }.each do |ci|
  next unless ly.is_valid_cell_index?(ci)
  ly.prune_cell(ci, -1) if ly.cell(ci).name != "siso_shift_register"
end

top = ly.top_cells.first
cnt = Hash.new(0)
top.each_inst { |i| cnt[i.cell.name] += 1 }
cnt.sort.each { |k, v| puts "#{v} #{k}" }
puts "top cells left: #{ly.top_cells.map { |c| c.name }.join(',')}"
ly.write("gds/siso_shift_register_new.gds")
puts "written gds/siso_shift_register_new.gds"
