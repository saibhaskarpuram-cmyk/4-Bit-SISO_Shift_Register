import os, re
V = os.environ["V"]
H = os.path.expanduser("~/siso_shift_register")
def headers(path):
    txt = open(path).read().replace("\n+", " ")
    d = {}
    for m in re.finditer(r"^\.subckt\s+(\S+)\s+(.*)$", txt, re.M | re.I):
        d[m.group(1)] = m.group(2).split()
    return d
old = headers(H + "/lvs/pdk_min.spice")
new = headers(V + "/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice")
out = [".include " + V + "/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice"]
for line in open(H + "/lvs/siso_schematic2.spice"):
    s = line.strip()
    if s.lower().startswith(".include"):
        continue
    if s.startswith("X"):
        t = s.split()
        name, nets, cell = t[0], t[1:-1], t[-1]
        m = dict(zip(old[cell], nets))
        m.setdefault("VNB", "VGND")
        m.setdefault("VPB", "VPWR")
        s = " ".join([name] + [m[p] for p in new[cell]] + [cell])
    out.append(s.replace("shift_reg_3_", "serial_out"))
open("siso_ref_pdk.spice", "w").write("\n".join(out) + "\n")
print("instances written:", sum(1 for l in out if l.startswith("X")))
