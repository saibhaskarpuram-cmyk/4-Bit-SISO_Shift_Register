set V $env(V)
set D $env(HOME)/siso_shift_register
gds read $V/libs.ref/sky130_fd_sc_hd/gds/sky130_fd_sc_hd.gds
lef read $V/libs.ref/sky130_fd_sc_hd/techlef/sky130_fd_sc_hd__nom.tlef
def read $D/pnr/06_droute_fill_fix3.def
load siso_shift_register
select top cell
gds write siso_magic_fix3.gds
extract do local
extract no capacitance
extract no coupling
extract no resistance
extract no adjust
extract unique
extract warn all
extract all
ext2spice lvs
ext2spice -o siso_magic_fix3.spice
quit
