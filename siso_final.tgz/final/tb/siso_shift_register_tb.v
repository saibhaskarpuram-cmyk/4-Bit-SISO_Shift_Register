`timescale 1ns/1ps

module siso_shift_register_tb;

reg clk;
reg rst;
reg serial_in;
wire serial_out;

siso_shift_register uut (
    .clk(clk),
    .rst(rst),
    .serial_in(serial_in),
    .serial_out(serial_out)
);

always #5 clk = ~clk;

initial begin
    $dumpfile("sim/siso_shift_register.vcd");
    $dumpvars(0, siso_shift_register_tb);

    clk = 0;
    rst = 1;
    serial_in = 0;

    #12;
    rst = 0;

    serial_in = 1; #10;
    serial_in = 0; #10;
    serial_in = 1; #10;
    serial_in = 1; #10;
    serial_in = 0; #10;
    serial_in = 0; #10;

    #10;
    $finish;
end

initial begin
    $monitor("Time=%0t rst=%b serial_in=%b serial_out=%b",
             $time, rst, serial_in, serial_out);
end

endmodule
