`timescale 1ns/1ps

module siso_shift_register_tb_sc;

reg  clk       = 1'b0;
reg  rst       = 1'b1;
reg  serial_in = 1'b0;
wire serial_out;

integer errors = 0;
integer checks = 0;
reg     checking = 1'b0;
integer lat, ones;

siso_shift_register uut (
    .clk(clk), .rst(rst), .serial_in(serial_in), .serial_out(serial_out)
);

always #5 clk = ~clk;

// ---------- reference model ----------
reg [3:0] ref_sr = 4'bxxxx;
always @(posedge clk) begin
    if (rst) begin
        ref_sr   <= 4'b0000;
        checking <= 1'b1;
    end else
        ref_sr <= {ref_sr[2:0], serial_in};
end

// ---------- checker: compares on every falling edge ----------
always @(negedge clk) begin
    if (checking) begin
        checks = checks + 1;
        if (serial_out !== ref_sr[3]) begin
            errors = errors + 1;
            $display("FAIL  t=%0d ns  serial_out=%b expected=%b", $time, serial_out, ref_sr[3]);
        end
    end
end

// ---------- stimulus helpers (inputs change on falling edge) ----------
task drive(input r, input d);
begin
    @(negedge clk);
    rst = r;
    serial_in = d;
end
endtask

task send_bits(input [15:0] bits, input integer n);
integer k;
begin
    for (k = n-1; k >= 0; k = k-1)
        drive(1'b0, bits[k]);
end
endtask

task flush;
integer m;
begin
    for (m = 0; m < 6; m = m + 1) drive(1'b0, 1'b0);
end
endtask

// ---------- independent latency test (does not use the model) ----------
task test_latency;
integer j;
begin
    drive(1,0); drive(1,0);
    drive(0,0); drive(0,0); drive(0,0); drive(0,0);
    lat = 0; ones = 0;
    drive(0,1);                      // single 1, captured at the next clock edge
    for (j = 1; j <= 8; j = j + 1) begin
        drive(0,0);
        if (serial_out === 1'b1) begin
            ones = ones + 1;
            if (lat == 0) lat = j;
        end
    end
    if (lat !== 4 || ones !== 1) begin
        errors = errors + 1;
        $display("FAIL  latency: first 1 after %0d edges (expected 4), %0d ones seen (expected 1)", lat, ones);
    end else
        $display("PASS  latency: input appears at serial_out after exactly 4 clock edges");
end
endtask

integer i;

initial begin
    $dumpfile("sim/siso_shift_register_sc.vcd");
    $dumpvars(0, siso_shift_register_tb_sc);

    $display("Test 1: reset with serial_in held high");
    drive(1,1); drive(1,1); drive(1,1);
    flush;

    $display("Test 2: directed pattern 10110010");
    send_bits(16'b10110010, 8);
    flush;

    $display("Test 3: all ones, then all zeros");
    send_bits(16'hFFFF, 8);
    send_bits(16'h0000, 8);

    $display("Test 4: alternating 1010...");
    send_bits(16'hAAAA, 16);
    flush;

    $display("Test 5: latency");
    test_latency;

    $display("Test 6: reset in the middle of a stream (output is 1 at reset)");
    send_bits(16'hFFFF, 6);
    drive(1,1);
    send_bits(16'hFFFF, 6);
    flush;

    $display("Test 7: reset held for 6 cycles with serial_in = 1");
    for (i = 0; i < 6; i = i + 1) drive(1,1);
    flush;

    $display("Test 8: 300 random cycles with random resets");
    for (i = 0; i < 300; i = i + 1)
        drive(({$random} % 16) == 0, $random);
    flush;

    repeat (3) drive(0,0);
    $display("------------------------------------------");
    $display("Checks performed: %0d    Errors: %0d", checks, errors);
    if (errors == 0) $display("RESULT: PASS");
    else             $display("RESULT: FAIL");
    $finish;
end

initial begin
    #200000;
    $display("TIMEOUT");
    $finish;
end

endmodule
